import io
from docx import Document
import fitz
from engine import (
    Criterion, extract_document, extract_requirements, evaluate,
    match_criterion, parsing_diagnostic, make_resume_units, contains_phrase,
)

JOB = '''Strategy Analyst
Responsibilities
• Develop client presentations and market research
• Work with cross-functional teams to manage projects
Required Qualifications
• Experience with Excel and PowerPoint
• Stakeholder engagement experience in healthcare
• At least 3 years of professional experience
Preferred Qualifications
• Experience using SQL
Benefits
• Generous health benefits and paid leave
'''
RESUME = '''PROFESSIONAL EXPERIENCE
Healthcare Consultant
• Delivered client presentations and performed market research in healthcare.
• Coordinated cross-functional teams on implementation projects.
• Analyzed utilization in Excel and designed slides in PowerPoint.
• Led stakeholder management with clinical executives.
EDUCATION
Bachelor of Health Sciences and MBA.
'''

def test_requirement_extraction():
    items = extract_requirements(JOB)
    assert any('Excel' in c.requirement and c.category == 'Required' for c in items)
    assert any('SQL' in c.requirement and c.category == 'Preferred' for c in items)
    assert any('client presentations' in c.requirement and c.category == 'Responsibilities' for c in items)
    assert not any('Generous' in c.requirement for c in items)


def test_scoring_deterministic_and_manual_excluded():
    records = [vars(c) for c in extract_requirements(JOB)]
    a = evaluate(records, RESUME)
    b = evaluate(records, RESUME)
    assert a == b
    assert a['manual'] == 1
    assert a['assessed'] >= 4
    assert 0 <= a['score'] <= 100
    assert any(r['status'] != 'Not evidenced' for r in a['results'])


def test_missing_skill_not_misattributed():
    answer = match_criterion('Experience using SQL', make_resume_units(RESUME))
    assert answer['credit'] == 0


def test_match_synonym():
    result = match_criterion('Stakeholder engagement', ['Led stakeholder management for hospital executives'])
    assert result['credit'] > 0


def test_no_keyword_stuffing_boost():
    crit = [{'requirement':'SQL', 'category':'Required', 'include':True, 'importance':1}]
    x = evaluate(crit, 'Professional experience with Excel and patient care')
    y = evaluate(crit, 'Professional experience with Excel and patient care\n' * 10)
    assert x['score'] == y['score'] == 0


def test_java_not_javascript():
    assert not contains_phrase('JavaScript developer', 'Java')


def test_negative_statement_not_evidence():
    r = match_criterion('Expertise in SQL', ['No expertise in SQL'])
    assert r['credit'] == 0


def test_docx_document():
    doc = Document()
    doc.add_heading('Experience', 1)
    doc.add_paragraph('Worked on healthcare market research')
    doc.add_table(rows=1, cols=2).rows[0].cells[0].text = 'Excel'
    mem = io.BytesIO()
    doc.save(mem)
    parsed = extract_document(mem.getvalue(), 'test.docx')
    assert 'market research' in parsed.text
    assert 'Excel' in parsed.text
    assert parsed.stats['tables'] == 1


def test_text_based_pdf():
    doc = fitz.open()
    pg = doc.new_page()
    pg.insert_text((72, 90), 'Market research and healthcare consulting')
    data = doc.tobytes()
    doc.close()
    parsed = extract_document(data, 'resume.pdf')
    assert 'Market research' in parsed.text
    assert parsed.stats['pages'] == 1


def test_scanned_pdf_warns():
    doc = fitz.open()
    doc.new_page()
    payload = doc.tobytes()
    doc.close()
    parsed = extract_document(payload, 'scan.pdf')
    score, issues = parsing_diagnostic(parsed)
    assert score <= 35
    assert any('image-only' in i for i in issues)


def test_no_assessed_score_none():
    criteria = [{'requirement': 'Must have 5 years experience', 'category':'Required', 'importance':1}]
    result = evaluate(criteria, RESUME)
    assert result['score'] is None
    assert result['manual'] == 1


def test_software_requirements_across_bullets():
    r = match_criterion('Experience with SQL and Tableau', [
        'Queried operational data using SQL', 'Created Tableau dashboard for leadership'])
    assert r['credit'] >= .65
    assert 'SQL' in r['evidence'] and 'Tableau' in r['evidence']
